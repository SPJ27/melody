# Melody

Melody is a python based web framework designed to let users build websites as fast as possible, with almost no boilerplate code.

Till now, I have built-
1. A Response and Request Class
2. A very basic CLI to run and deploy the apps
3. Dynamic routing with slugs (built on Werkzeug)
4. Reading environment variables
5. A basic sqlite3 ORM (built on peewee orm)

## 1. How to build a simple app

You first need to install melody by
```bash
pip install melody
```

```python
# routes.py
from .controllers import *

routes = [
    '/': index,
    'POST /new': new
]
```

This is the basic snippet for running the code. You can either create a new file for storing the controllers, or define them in the routes.py itself.

To run your app, you can
